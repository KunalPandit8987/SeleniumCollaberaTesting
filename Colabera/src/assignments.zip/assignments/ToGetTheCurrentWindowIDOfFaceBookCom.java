package assignments;

import org.openqa.selenium.chrome.ChromeDriver;

public class ToGetTheCurrentWindowIDOfFaceBookCom {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://www.FaceBook.com/");
		String window=driver.getWindowHandle();
		System.out.println(window);


	}

}
